#ifndef __INC_MAIN_H__
#define __INC_MAIN_H__

int	Start();
void End();
const char* GetTablePostfix();
const char* GetPlayerDBName();

#endif
