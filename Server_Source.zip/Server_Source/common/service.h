#ifndef __INC_SERVICE_H__
#define __INC_SERVICE_H__
#pragma once
//  ============================================

//  --------------------------------------------
// |	Stock Defines							|
//  --------------------------------------------
#define _IMPROVED_PACKET_ENCRYPTION_			// ��Ŷ ��ȣȭ ����
#define __PET_SYSTEM__
#define __UDP_BLOCK__

//  --------------------------------------------
// |	New Defines								|
//  --------------------------------------------
#define CLIENT_LOCALE_STRING					// [REVERSED] Client Locale String	* Author: Mali		*

//  --------------------------------------------
// |	Fixes									|
//  --------------------------------------------
#define LEVEL_FIX								// [REVERSED] Level Update Fix	* Author: Mali			*

//  ============================================
#endif