#ifndef __INC_METIN_II_PANAMA_H__
#define __INC_METIN_II_PANAMA_H__

extern size_t PanamaLoad();
extern void SendPanamaList(LPDESC d);

#endif
