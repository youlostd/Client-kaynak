#if !defined(_MSC_VER) && defined(__cplusplus)
extern "C" {
#endif

#include <lua.h>
#include <lauxlib.h>
#include <lualib.h>

	#if !defined(_MSC_VER) && defined(__cplusplus)
}
	#endif
