#pragma once

void initdbg();
