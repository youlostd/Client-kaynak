#pragma once

#pragma warning(disable:4786)	// character 255 �Ѿ�°� ����

//#include <crtdbg.h>
#include <Granny-2.11.8/granny.h>

#include "../eterBase/Utils.h"
#include "../eterBase/Debug.h"
#include "../eterBase/Stl.h"

#include "Util.h"
